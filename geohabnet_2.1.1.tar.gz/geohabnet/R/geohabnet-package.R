#' @keywords internal
"_PACKAGE"

## usethis namespace: start

#' @importFrom methods setClass setGeneric setMethod setRefClass new validObject
#' @references
#' Global Cropland Connectivity: A Risk Factor for Invasion and Saturation by Emerging Pathogens and Pests
## usethis namespace: end
NULL
