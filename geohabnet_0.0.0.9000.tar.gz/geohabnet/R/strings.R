# contains string literals. -----------------------------------------------

# CCRI metrics ------------------------------------------------------------

# nolint start: object_name_linter
STR_BETWEENNESS <- "betweeness"
STR_NODE_STRENGTH <- "node_strength"
STR_NEAREST_NEIGHBORS_SUM <- "sum_of_nearest_neighbors"
STR_EIGEN_VECTOR_CENTRALITY <- "eigenvector_centrality"
# nolint end
