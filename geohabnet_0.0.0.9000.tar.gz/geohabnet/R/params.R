library(yaml)

get_parameters <- function() {
  
}
set_parameter <- function(name, value = NULL) {
  
}