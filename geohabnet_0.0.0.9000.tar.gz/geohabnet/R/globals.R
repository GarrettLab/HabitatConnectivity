utils::globalVariables(c("cropharvest_agglm_crop", "cropharvest_aggtm_crop", "distance_matrix", "is_initialized",
                         "result_index_list", "parameters_config"))
