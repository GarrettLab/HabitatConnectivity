## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----eval = FALSE-------------------------------------------------------------
#  if (!require("devtools")) {
#    install.packages("devtools")
#  }

## ----setup, eval=FALSE--------------------------------------------------------
#  
#  if (!require("geohabnet")) {
#    utils::install.packages("geohabnet")
#  }

## ----cran, eval=FALSE---------------------------------------------------------
#  library("devtools")
#  
#  if (!require("geohabnet")) {
#    install_github("GarrettLab/CroplandConnectivity", subdir = "geohabnet")
#  }
