#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @references
#' Global Cropland Connectivity: A Risk Factor for Invasion and Saturation by Emerging Pathogens and Pests
#' [https://doi.org/10.1093/biosci/biaa067]
## usethis namespace: end
NULL
