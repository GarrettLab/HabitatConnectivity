## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, eval=FALSE--------------------------------------------------------
#  knitr::opts_chunk$set(echo = TRUE)
#  if (!require(geohabnet)) {
#    install.packages("geohabnet")
#    library(geohabnet)
#  }

## ----echo=TRUE, eval=FALSE----------------------------------------------------
#  avo_rast <- get_rasters(list(monfreda = c("avocado")))
#  avo_rast

## ----echo=TRUE, eval=FALSE----------------------------------------------------
#  dmets <- dist_methods()
#  dmets

## ----echo=TRUE, eval=FALSE----------------------------------------------------
#  if (!require(microbenchmark)) {
#   install.packages("microbenchmark")
#    library(microbenchmark)
#  }

## ----echo=TRUE, eval=FALSE----------------------------------------------------
#  sa <- function(rast, distm) {
#    sa_onrasters(rast,
#                 dist_method = distm,
#                 link_thresholds = c(0),
#                 host_density_thresholds = c(0))
#  }

## ----echo=TRUE, eval=FALSE----------------------------------------------------
#  bres <- microbenchmark(sa(avo_rast[[1]], dmets[1]),
#                 sa(avo_rast[[1]], dmets[2]),
#                 times = 1)
#  bres

