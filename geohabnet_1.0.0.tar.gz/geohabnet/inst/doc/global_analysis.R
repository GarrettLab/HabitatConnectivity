## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----eval=FALSE---------------------------------------------------------------
#  devtools::install_github("GarrettLab/CroplandConnectivity",
#                           subdir = "geohabnet", auth_token = "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")

## ----eval=FALSE---------------------------------------------------------------
#  #install.packages("geohabnet") # do not run this
#  library(geohabnet)
#  interactive()

## ----eval=FALSE---------------------------------------------------------------
#  x <- sensitivity_analysis()

## ----eval=FALSE---------------------------------------------------------------
#  search_crop("avocado")

## ----eval=FALSE---------------------------------------------------------------
#  myrast <- get_rasters(list(monfreda = c("avocado")))[[1]]
#  # visualizing the intial raster
#  terra::plot(myrast)

## ----eval=FALSE---------------------------------------------------------------
#  results <- sean(link_threshold = 0.0000015, rast = myrast, res = 24)

